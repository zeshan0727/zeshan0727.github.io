#import "PhoneAuraManager.h"
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>

static NSString * const PADomain = @"com.zeshan.phoneaura";
static NSString * const PANotification = @"com.zeshan.phoneaura/preferences.changed";
static NSInteger const PABackgroundTag = 915001;
static NSInteger const PAHeaderTag = 915002;
static NSInteger const PADockTag = 915003;
static NSInteger const PACardTag = 915004;
static NSInteger const PAKeypadTag = 915005;

static id PARead(NSString *key) {
    return CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)key,
                                                        (__bridge CFStringRef)PADomain));
}

static BOOL PABool(NSString *key, BOOL fallback) {
    id value = PARead(key);
    return value ? [value boolValue] : fallback;
}

static NSInteger PAInteger(NSString *key, NSInteger fallback) {
    id value = PARead(key);
    return value ? [value integerValue] : fallback;
}

static void PAWrite(NSString *key, id value) {
    CFPreferencesSetAppValue((__bridge CFStringRef)key,
                             (__bridge CFPropertyListRef)value,
                             (__bridge CFStringRef)PADomain);
    CFPreferencesAppSynchronize((__bridge CFStringRef)PADomain);
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(),
                                         (__bridge CFStringRef)PANotification,
                                         NULL, NULL, true);
}

static UIColor *PAAccent(void) {
    switch (PAInteger(@"accentStyle", 0)) {
        case 1: return [UIColor colorWithRed:0.69 green:0.42 blue:1.00 alpha:1.0];
        case 2: return [UIColor colorWithRed:0.18 green:0.90 blue:0.68 alpha:1.0];
        case 3: return [UIColor colorWithRed:1.00 green:0.43 blue:0.32 alpha:1.0];
        default: return [UIColor colorWithRed:0.15 green:0.68 blue:1.00 alpha:1.0];
    }
}

static NSArray<UIColor *> *PAPalette(void) {
    switch (PAInteger(@"accentStyle", 0)) {
        case 1: return @[[UIColor colorWithRed:0.035 green:0.025 blue:0.10 alpha:1],
                         [UIColor colorWithRed:0.18 green:0.055 blue:0.29 alpha:1],
                         [UIColor colorWithRed:0.02 green:0.025 blue:0.075 alpha:1]];
        case 2: return @[[UIColor colorWithRed:0.012 green:0.065 blue:0.075 alpha:1],
                         [UIColor colorWithRed:0.015 green:0.20 blue:0.17 alpha:1],
                         [UIColor colorWithRed:0.01 green:0.035 blue:0.055 alpha:1]];
        case 3: return @[[UIColor colorWithRed:0.105 green:0.025 blue:0.045 alpha:1],
                         [UIColor colorWithRed:0.30 green:0.065 blue:0.08 alpha:1],
                         [UIColor colorWithRed:0.045 green:0.018 blue:0.065 alpha:1]];
        default: return @[[UIColor colorWithRed:0.006 green:0.035 blue:0.09 alpha:1],
                          [UIColor colorWithRed:0.015 green:0.17 blue:0.30 alpha:1],
                          [UIColor colorWithRed:0.025 green:0.018 blue:0.105 alpha:1]];
    }
}

static void PAHaptic(UIImpactFeedbackStyle style) {
    if (!PABool(@"haptics", YES)) return;
    UIImpactFeedbackGenerator *generator = [[UIImpactFeedbackGenerator alloc] initWithStyle:style];
    [generator prepare];
    [generator impactOccurred];
}

#pragma mark - Atmosphere

@interface PAAuroraBackground : UIView
@property (nonatomic, strong) CAGradientLayer *gradient;
@property (nonatomic, strong) UIView *orbTop;
@property (nonatomic, strong) UIView *orbBottom;
- (void)refresh;
@end

@implementation PAAuroraBackground
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.userInteractionEnabled = NO;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _gradient = [CAGradientLayer layer];
    _gradient.startPoint = CGPointMake(0.05, 0.0);
    _gradient.endPoint = CGPointMake(0.95, 1.0);
    _gradient.locations = @[@0.0, @0.52, @1.0];
    [self.layer addSublayer:_gradient];

    _orbTop = [[UIView alloc] initWithFrame:CGRectZero];
    _orbTop.layer.cornerRadius = 150;
    _orbTop.layer.shadowRadius = 70;
    _orbTop.layer.shadowOpacity = 0.65;
    _orbTop.layer.shadowOffset = CGSizeZero;
    [self addSubview:_orbTop];

    _orbBottom = [[UIView alloc] initWithFrame:CGRectZero];
    _orbBottom.layer.cornerRadius = 130;
    _orbBottom.layer.shadowRadius = 65;
    _orbBottom.layer.shadowOpacity = 0.48;
    _orbBottom.layer.shadowOffset = CGSizeZero;
    [self addSubview:_orbBottom];
    [self refresh];
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    self.gradient.frame = self.bounds;
    CGFloat width = CGRectGetWidth(self.bounds);
    CGFloat height = CGRectGetHeight(self.bounds);
    self.orbTop.frame = CGRectMake(width - 175, -115, 300, 300);
    self.orbBottom.frame = CGRectMake(-150, height * 0.55, 260, 260);
}

- (void)refresh {
    NSMutableArray *colors = [NSMutableArray array];
    for (UIColor *color in PAPalette()) [colors addObject:(id)color.CGColor];
    self.gradient.colors = colors;
    UIColor *accent = PAAccent();
    self.orbTop.backgroundColor = [accent colorWithAlphaComponent:0.16];
    self.orbTop.layer.shadowColor = accent.CGColor;
    self.orbBottom.backgroundColor = [accent colorWithAlphaComponent:0.10];
    self.orbBottom.layer.shadowColor = accent.CGColor;
}
@end

#pragma mark - Header

@class PhoneAuraManager;

@interface PAHeaderView : UIView
@property (nonatomic, weak) PhoneAuraManager *manager;
@property (nonatomic, strong) UILabel *eyebrow;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UIButton *searchButton;
@property (nonatomic, strong) UIButton *addButton;
@property (nonatomic, strong) UIButton *settingsButton;
@property (nonatomic, strong) UIStackView *filters;
@property (nonatomic, strong) UIButton *allButton;
@property (nonatomic, strong) UIButton *missedButton;
@property (nonatomic, assign) NSInteger tabIndex;
- (void)configureForIndex:(NSInteger)index;
- (void)setMissedSelected:(BOOL)missed;
@end

@implementation PAHeaderView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = UIColor.clearColor;

    _eyebrow = [[UILabel alloc] initWithFrame:CGRectZero];
    _eyebrow.text = @"PHONEAURA";
    _eyebrow.font = [UIFont systemFontOfSize:10 weight:UIFontWeightHeavy];
    _eyebrow.textColor = [PAAccent() colorWithAlphaComponent:0.95];
    _eyebrow.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_eyebrow];

    _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _titleLabel.font = [UIFont systemFontOfSize:32 weight:UIFontWeightBold];
    _titleLabel.textColor = UIColor.whiteColor;
    _titleLabel.adjustsFontSizeToFitWidth = YES;
    _titleLabel.minimumScaleFactor = 0.8;
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_titleLabel];

    _subtitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _subtitleLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightMedium];
    _subtitleLabel.textColor = [UIColor colorWithWhite:1 alpha:0.52];
    _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_subtitleLabel];

    _searchButton = [self circleButton:@"magnifyingglass" action:@selector(searchPressed)];
    _addButton = [self circleButton:@"plus" action:@selector(addPressed)];
    _settingsButton = [self circleButton:@"slider.horizontal.3" action:@selector(settingsPressed)];

    UIStackView *actions = [[UIStackView alloc] initWithArrangedSubviews:@[_searchButton, _addButton, _settingsButton]];
    actions.axis = UILayoutConstraintAxisHorizontal;
    actions.spacing = 8;
    actions.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:actions];

    _allButton = [self filterButton:@"All" action:@selector(allPressed)];
    _missedButton = [self filterButton:@"Missed" action:@selector(missedPressed)];
    _filters = [[UIStackView alloc] initWithArrangedSubviews:@[_allButton, _missedButton]];
    _filters.axis = UILayoutConstraintAxisHorizontal;
    _filters.spacing = 8;
    _filters.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_filters];

    [NSLayoutConstraint activateConstraints:@[
        [_eyebrow.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:20],
        [_eyebrow.topAnchor constraintEqualToAnchor:self.topAnchor constant:2],
        [_titleLabel.leadingAnchor constraintEqualToAnchor:_eyebrow.leadingAnchor],
        [_titleLabel.topAnchor constraintEqualToAnchor:_eyebrow.bottomAnchor constant:3],
        [_titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:actions.leadingAnchor constant:-10],
        [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_eyebrow.leadingAnchor],
        [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:1],
        [actions.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-18],
        [actions.topAnchor constraintEqualToAnchor:self.topAnchor constant:14],
        [_searchButton.widthAnchor constraintEqualToConstant:38],
        [_searchButton.heightAnchor constraintEqualToConstant:38],
        [_addButton.widthAnchor constraintEqualToConstant:38],
        [_addButton.heightAnchor constraintEqualToConstant:38],
        [_settingsButton.widthAnchor constraintEqualToConstant:38],
        [_settingsButton.heightAnchor constraintEqualToConstant:38],
        [_filters.leadingAnchor constraintEqualToAnchor:_eyebrow.leadingAnchor],
        [_filters.topAnchor constraintEqualToAnchor:_subtitleLabel.bottomAnchor constant:11],
        [_filters.heightAnchor constraintEqualToConstant:34]
    ]];

    [self setMissedSelected:NO];
    return self;
}

- (UIButton *)circleButton:(NSString *)symbol action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    UIImageSymbolConfiguration *config = [UIImageSymbolConfiguration configurationWithPointSize:15 weight:UIImageSymbolWeightSemibold];
    [button setImage:[UIImage systemImageNamed:symbol withConfiguration:config] forState:UIControlStateNormal];
    button.tintColor = UIColor.whiteColor;
    button.backgroundColor = [UIColor colorWithWhite:1 alpha:0.085];
    button.layer.cornerRadius = 19;
    button.layer.cornerCurve = kCACornerCurveContinuous;
    button.layer.borderWidth = 0.6;
    button.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.13].CGColor;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    return button;
}

- (UIButton *)filterButton:(NSString *)title action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    button.contentEdgeInsets = UIEdgeInsetsMake(7, 17, 7, 17);
    button.layer.cornerRadius = 17;
    button.layer.cornerCurve = kCACornerCurveContinuous;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)configureForIndex:(NSInteger)index {
    self.tabIndex = index;
    NSArray *titles = @[@"Your circle", @"Call history", @"People", @"Dial", @"Voice inbox"];
    NSArray *subtitles = @[@"The people who matter most",
                           @"Calls, grouped clearly",
                           @"Search every connection",
                           @"A cleaner way to call",
                           @"Messages waiting for you"];
    if (index >= 0 && index < titles.count) {
        self.titleLabel.text = titles[index];
        self.subtitleLabel.text = subtitles[index];
    }
    self.filters.hidden = index != 1;
    self.searchButton.hidden = index == 3 || index == 4;
    self.addButton.hidden = index == 1 || index == 3 || index == 4;
    self.eyebrow.textColor = PAAccent();
}

- (void)setMissedSelected:(BOOL)missed {
    UIButton *selected = missed ? self.missedButton : self.allButton;
    UIButton *normal = missed ? self.allButton : self.missedButton;
    selected.backgroundColor = [PAAccent() colorWithAlphaComponent:0.90];
    [selected setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    normal.backgroundColor = [UIColor colorWithWhite:1 alpha:0.08];
    [normal setTitleColor:[UIColor colorWithWhite:1 alpha:0.58] forState:UIControlStateNormal];
}

- (void)searchPressed { [self.manager performSelector:@selector(headerSearchPressed)]; }
- (void)addPressed { [self.manager performSelector:@selector(headerAddPressed)]; }
- (void)settingsPressed { [self.manager performSelector:@selector(presentSettings)]; }
- (void)allPressed { [self setMissedSelected:NO]; [self.manager performSelector:@selector(showAllRecents)]; }
- (void)missedPressed { [self setMissedSelected:YES]; [self.manager performSelector:@selector(showMissedRecents)]; }
@end

#pragma mark - Dock

@interface PAOrbitDock : UIVisualEffectView
@property (nonatomic, weak) PhoneAuraManager *manager;
@property (nonatomic, strong) UIStackView *stack;
@property (nonatomic, strong) UIView *indicator;
@property (nonatomic, strong) NSArray<UIButton *> *buttons;
@property (nonatomic, assign) NSInteger selectedIndex;
- (void)setSelectedIndex:(NSInteger)index animated:(BOOL)animated;
- (void)refresh;
@end

@implementation PAOrbitDock
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark]];
    if (!self) return nil;
    self.clipsToBounds = NO;
    self.layer.cornerRadius = 29;
    self.layer.cornerCurve = kCACornerCurveContinuous;
    self.layer.borderWidth = 0.7;
    self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.16].CGColor;
    self.layer.shadowOpacity = 0.35;
    self.layer.shadowRadius = 22;
    self.layer.shadowOffset = CGSizeMake(0, 12);

    _indicator = [[UIView alloc] initWithFrame:CGRectZero];
    _indicator.userInteractionEnabled = NO;
    _indicator.layer.cornerRadius = 21;
    _indicator.layer.cornerCurve = kCACornerCurveContinuous;
    [self.contentView addSubview:_indicator];

    _stack = [[UIStackView alloc] initWithFrame:CGRectZero];
    _stack.axis = UILayoutConstraintAxisHorizontal;
    _stack.distribution = UIStackViewDistributionFillEqually;
    _stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.contentView addSubview:_stack];
    [NSLayoutConstraint activateConstraints:@[
        [_stack.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:8],
        [_stack.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-8],
        [_stack.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:5],
        [_stack.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-5]
    ]];

    NSArray *symbols = @[@"star.fill", @"clock.arrow.circlepath", @"person.2.fill", @"circle.grid.3x3.fill", @"waveform"];
    NSArray *labels = @[@"Favorites", @"Recents", @"Contacts", @"Keypad", @"Voicemail"];
    NSMutableArray *buttons = [NSMutableArray array];
    for (NSInteger index = 0; index < symbols.count; index++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = index;
        button.accessibilityLabel = labels[index];
        UIImageSymbolConfiguration *config = [UIImageSymbolConfiguration configurationWithPointSize:19 weight:UIImageSymbolWeightSemibold];
        [button setImage:[UIImage systemImageNamed:symbols[index] withConfiguration:config] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(tapped:) forControlEvents:UIControlEventTouchUpInside];
        [self.stack addArrangedSubview:button];
        [buttons addObject:button];
    }
    self.buttons = buttons;
    [self refresh];
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat innerWidth = CGRectGetWidth(self.bounds) - 16;
    CGFloat unit = innerWidth / 5.0;
    self.indicator.frame = CGRectMake(8 + unit * self.selectedIndex + (unit - 42) / 2, 8, 42, 42);
}

- (void)tapped:(UIButton *)sender {
    [self.manager performSelector:@selector(dockButtonPressed:) withObject:sender];
}

- (void)refresh {
    UIColor *accent = PAAccent();
    self.indicator.backgroundColor = [accent colorWithAlphaComponent:0.24];
    self.layer.shadowColor = accent.CGColor;
    for (NSInteger index = 0; index < self.buttons.count; index++) {
        UIButton *button = self.buttons[index];
        BOOL selected = index == self.selectedIndex;
        button.tintColor = selected ? accent : [UIColor colorWithWhite:1 alpha:0.48];
        button.transform = selected ? CGAffineTransformMakeScale(1.10, 1.10) : CGAffineTransformIdentity;
        button.accessibilityTraits = selected ? UIAccessibilityTraitSelected : UIAccessibilityTraitButton;
    }
}

- (void)setSelectedIndex:(NSInteger)index animated:(BOOL)animated {
    _selectedIndex = index;
    void (^changes)(void) = ^{
        [self setNeedsLayout];
        [self layoutIfNeeded];
        [self refresh];
    };
    if (animated && PABool(@"animations", YES)) {
        [UIView animateWithDuration:0.42 delay:0 usingSpringWithDamping:0.70 initialSpringVelocity:0.45 options:UIViewAnimationOptionBeginFromCurrentState|UIViewAnimationOptionAllowUserInteraction animations:changes completion:nil];
    } else {
        changes();
    }
}
@end

#pragma mark - Custom keypad

@interface PAKeyButton : UIControl
@property (nonatomic, strong) UILabel *numberLabel;
@property (nonatomic, strong) UILabel *lettersLabel;
@property (nonatomic, copy) NSString *value;
@end

@implementation PAKeyButton
- (instancetype)initWithValue:(NSString *)value letters:(NSString *)letters {
    self = [super initWithFrame:CGRectZero];
    if (!self) return nil;
    self.value = value;
    self.backgroundColor = [UIColor colorWithWhite:1 alpha:0.075];
    self.layer.cornerRadius = 39;
    self.layer.cornerCurve = kCACornerCurveContinuous;
    self.layer.borderWidth = 0.7;
    self.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.14].CGColor;

    _numberLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _numberLabel.text = value;
    _numberLabel.textAlignment = NSTextAlignmentCenter;
    _numberLabel.textColor = UIColor.whiteColor;
    _numberLabel.font = [UIFont systemFontOfSize:31 weight:UIFontWeightMedium];
    _numberLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_numberLabel];

    _lettersLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    _lettersLabel.text = letters;
    _lettersLabel.textAlignment = NSTextAlignmentCenter;
    _lettersLabel.textColor = [UIColor colorWithWhite:1 alpha:0.50];
    _lettersLabel.font = [UIFont systemFontOfSize:9.5 weight:UIFontWeightBold];
    _lettersLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_lettersLabel];

    [NSLayoutConstraint activateConstraints:@[
        [self.widthAnchor constraintEqualToConstant:78],
        [self.heightAnchor constraintEqualToConstant:78],
        [_numberLabel.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
        [_numberLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor constant:letters.length ? -6 : 0],
        [_lettersLabel.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
        [_lettersLabel.topAnchor constraintEqualToAnchor:_numberLabel.bottomAnchor constant:-2]
    ]];
    return self;
}

- (void)setHighlighted:(BOOL)highlighted {
    [super setHighlighted:highlighted];
    [UIView animateWithDuration:0.12 animations:^{
        self.transform = highlighted ? CGAffineTransformMakeScale(0.91, 0.91) : CGAffineTransformIdentity;
        self.backgroundColor = highlighted ? [PAAccent() colorWithAlphaComponent:0.24] : [UIColor colorWithWhite:1 alpha:0.075];
    }];
}
@end

@interface PACustomKeypadView : UIView
@property (nonatomic, strong) UILabel *numberDisplay;
@property (nonatomic, strong) UIButton *callButton;
@property (nonatomic, strong) UIButton *deleteButton;
@property (nonatomic, strong) NSMutableString *digits;
@end

@implementation PACustomKeypadView
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = UIColor.clearColor;
    self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _digits = [NSMutableString string];

    _numberDisplay = [[UILabel alloc] initWithFrame:CGRectZero];
    _numberDisplay.text = @"Tap a number";
    _numberDisplay.textAlignment = NSTextAlignmentCenter;
    _numberDisplay.textColor = [UIColor colorWithWhite:1 alpha:0.34];
    _numberDisplay.font = [UIFont monospacedDigitSystemFontOfSize:28 weight:UIFontWeightSemibold];
    _numberDisplay.adjustsFontSizeToFitWidth = YES;
    _numberDisplay.minimumScaleFactor = 0.58;
    _numberDisplay.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:_numberDisplay];

    UIStackView *grid = [[UIStackView alloc] initWithFrame:CGRectZero];
    grid.axis = UILayoutConstraintAxisVertical;
    grid.spacing = 14;
    grid.alignment = UIStackViewAlignmentCenter;
    grid.translatesAutoresizingMaskIntoConstraints = NO;
    [self addSubview:grid];

    NSArray *values = @[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"*",@"0",@"#"];
    NSArray *letters = @[@"",@"ABC",@"DEF",@"GHI",@"JKL",@"MNO",@"PQRS",@"TUV",@"WXYZ",@"",@"+",@""];
    for (NSInteger row = 0; row < 4; row++) {
        UIStackView *line = [[UIStackView alloc] initWithFrame:CGRectZero];
        line.axis = UILayoutConstraintAxisHorizontal;
        line.spacing = 22;
        for (NSInteger column = 0; column < 3; column++) {
            NSInteger index = row * 3 + column;
            PAKeyButton *key = [[PAKeyButton alloc] initWithValue:values[index] letters:letters[index]];
            [key addTarget:self action:@selector(keyPressed:) forControlEvents:UIControlEventTouchUpInside];
            if ([values[index] isEqualToString:@"0"]) {
                UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(zeroHeld:)];
                [key addGestureRecognizer:longPress];
            }
            [line addArrangedSubview:key];
        }
        [grid addArrangedSubview:line];
    }

    _callButton = [UIButton buttonWithType:UIButtonTypeSystem];
    UIImageSymbolConfiguration *callConfig = [UIImageSymbolConfiguration configurationWithPointSize:27 weight:UIImageSymbolWeightBold];
    [_callButton setImage:[UIImage systemImageNamed:@"phone.fill" withConfiguration:callConfig] forState:UIControlStateNormal];
    _callButton.tintColor = UIColor.whiteColor;
    _callButton.backgroundColor = [UIColor colorWithRed:0.15 green:0.82 blue:0.47 alpha:1.0];
    _callButton.layer.cornerRadius = 34;
    _callButton.layer.shadowColor = _callButton.backgroundColor.CGColor;
    _callButton.layer.shadowOpacity = 0.42;
    _callButton.layer.shadowRadius = 18;
    _callButton.layer.shadowOffset = CGSizeMake(0, 8);
    _callButton.translatesAutoresizingMaskIntoConstraints = NO;
    [_callButton addTarget:self action:@selector(callPressed) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_callButton];

    _deleteButton = [UIButton buttonWithType:UIButtonTypeSystem];
    UIImageSymbolConfiguration *deleteConfig = [UIImageSymbolConfiguration configurationWithPointSize:19 weight:UIImageSymbolWeightSemibold];
    [_deleteButton setImage:[UIImage systemImageNamed:@"delete.left.fill" withConfiguration:deleteConfig] forState:UIControlStateNormal];
    _deleteButton.tintColor = [UIColor colorWithWhite:1 alpha:0.52];
    _deleteButton.translatesAutoresizingMaskIntoConstraints = NO;
    [_deleteButton addTarget:self action:@selector(deletePressed) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:_deleteButton];

    [NSLayoutConstraint activateConstraints:@[
        [_numberDisplay.leadingAnchor constraintEqualToAnchor:self.leadingAnchor constant:28],
        [_numberDisplay.trailingAnchor constraintEqualToAnchor:self.trailingAnchor constant:-28],
        [_numberDisplay.topAnchor constraintEqualToAnchor:self.topAnchor constant:4],
        [_numberDisplay.heightAnchor constraintEqualToConstant:44],
        [grid.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
        [grid.topAnchor constraintEqualToAnchor:_numberDisplay.bottomAnchor constant:12],
        [_callButton.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
        [_callButton.topAnchor constraintEqualToAnchor:grid.bottomAnchor constant:17],
        [_callButton.widthAnchor constraintEqualToConstant:68],
        [_callButton.heightAnchor constraintEqualToConstant:68],
        [_deleteButton.centerYAnchor constraintEqualToAnchor:_callButton.centerYAnchor],
        [_deleteButton.leadingAnchor constraintEqualToAnchor:_callButton.trailingAnchor constant:44],
        [_deleteButton.widthAnchor constraintEqualToConstant:46],
        [_deleteButton.heightAnchor constraintEqualToConstant:46]
    ]];
    return self;
}

- (void)keyPressed:(PAKeyButton *)sender {
    if (self.digits.length >= 32) return;
    [self.digits appendString:sender.value ?: @""];
    [self refreshDisplay];
    PAHaptic(UIImpactFeedbackStyleLight);
}

- (void)zeroHeld:(UILongPressGestureRecognizer *)gesture {
    if (gesture.state != UIGestureRecognizerStateBegan || self.digits.length >= 32) return;
    [self.digits appendString:@"+"];
    [self refreshDisplay];
    PAHaptic(UIImpactFeedbackStyleMedium);
}

- (void)deletePressed {
    if (self.digits.length) [self.digits deleteCharactersInRange:NSMakeRange(self.digits.length - 1, 1)];
    [self refreshDisplay];
    PAHaptic(UIImpactFeedbackStyleLight);
}

- (void)refreshDisplay {
    BOOL empty = self.digits.length == 0;
    self.numberDisplay.text = empty ? @"Tap a number" : self.digits;
    self.numberDisplay.textColor = empty ? [UIColor colorWithWhite:1 alpha:0.34] : UIColor.whiteColor;
    self.deleteButton.alpha = empty ? 0.0 : 1.0;
}

- (void)callPressed {
    if (!self.digits.length) {
        PAHaptic(UIImpactFeedbackStyleHeavy);
        return;
    }
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"0123456789*#+"];
    NSString *clean = [[self.digits componentsSeparatedByCharactersInSet:allowed.invertedSet] componentsJoinedByString:@""];
    NSString *escaped = [clean stringByAddingPercentEncodingWithAllowedCharacters:NSCharacterSet.URLQueryAllowedCharacterSet];
    NSURL *url = [NSURL URLWithString:[@"tel:" stringByAppendingString:escaped ?: @""]];
    if (url) {
        PAHaptic(UIImpactFeedbackStyleHeavy);
        [UIApplication.sharedApplication openURL:url options:@{} completionHandler:nil];
    }
}
@end

#pragma mark - Manager

@interface PhoneAuraManager ()
@property (nonatomic, weak) UITabBarController *tabController;
@property (nonatomic, weak) PAOrbitDock *dock;
@property (nonatomic, weak) PAHeaderView *header;
@property (nonatomic, weak) UIViewController *keypadController;
@property (nonatomic, assign) BOOL applying;
@end

@implementation PhoneAuraManager

+ (instancetype)sharedManager {
    static PhoneAuraManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ manager = [[PhoneAuraManager alloc] init]; });
    return manager;
}

static void PASettingsChanged(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    PhoneAuraManager *manager = (__bridge PhoneAuraManager *)observer;
    dispatch_async(dispatch_get_main_queue(), ^{ [manager reloadPreferences]; });
}

- (instancetype)init {
    self = [super init];
    if (!self) return nil;
    CFNotificationCenterAddObserver(CFNotificationCenterGetDarwinNotifyCenter(),
                                    (__bridge const void *)self,
                                    PASettingsChanged,
                                    (__bridge CFStringRef)PANotification,
                                    NULL,
                                    CFNotificationSuspensionBehaviorDeliverImmediately);
    return self;
}

- (void)dealloc {
    CFNotificationCenterRemoveEveryObserver(CFNotificationCenterGetDarwinNotifyCenter(), (__bridge const void *)self);
}

- (void)reloadPreferences {
    if (!self.tabController) return;
    [self installChrome:self.tabController];
    [self updateForVisibleController:[self visibleControllerFrom:self.tabController]];
}

- (void)controllerDidAppear:(UIViewController *)controller {
    if (self.applying || !PABool(@"enabled", YES)) return;
    UITabBarController *tab = [self tabControllerForController:controller] ?: [self locateTabController];
    if (!tab) return;
    self.tabController = tab;
    [self installChrome:tab];
    [self updateForVisibleController:controller];
}

- (void)tabSelectionChanged:(UITabBarController *)tabController {
    if (!tabController) return;
    self.tabController = tabController;
    [self installChrome:tabController];
    [self.dock setSelectedIndex:tabController.selectedIndex animated:YES];
    [self.header configureForIndex:tabController.selectedIndex];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self updateForVisibleController:[self visibleControllerFrom:tabController]];
    });
    PAHaptic(UIImpactFeedbackStyleLight);
}

- (void)dockButtonPressed:(UIButton *)sender {
    if (!self.tabController || sender.tag >= self.tabController.viewControllers.count) return;
    self.tabController.selectedIndex = sender.tag;
    [self.dock setSelectedIndex:sender.tag animated:YES];
    [self.header configureForIndex:sender.tag];
    [self updateForVisibleController:[self visibleControllerFrom:self.tabController]];
    PAHaptic(UIImpactFeedbackStyleLight);
}

- (void)installChrome:(UITabBarController *)tab {
    self.applying = YES;
    tab.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
    tab.view.backgroundColor = UIColor.clearColor;
    tab.tabBar.hidden = YES;

    PAAuroraBackground *background = (PAAuroraBackground *)[tab.view viewWithTag:PABackgroundTag];
    if (![background isKindOfClass:PAAuroraBackground.class]) {
        background = [[PAAuroraBackground alloc] initWithFrame:tab.view.bounds];
        background.tag = PABackgroundTag;
        [tab.view insertSubview:background atIndex:0];
    }
    [background refresh];

    PAHeaderView *header = (PAHeaderView *)[tab.view viewWithTag:PAHeaderTag];
    if (![header isKindOfClass:PAHeaderView.class]) {
        header = [[PAHeaderView alloc] initWithFrame:CGRectZero];
        header.tag = PAHeaderTag;
        header.manager = self;
        header.translatesAutoresizingMaskIntoConstraints = NO;
        [tab.view addSubview:header];
        [NSLayoutConstraint activateConstraints:@[
            [header.leadingAnchor constraintEqualToAnchor:tab.view.leadingAnchor],
            [header.trailingAnchor constraintEqualToAnchor:tab.view.trailingAnchor],
            [header.topAnchor constraintEqualToAnchor:tab.view.safeAreaLayoutGuide.topAnchor constant:5],
            [header.heightAnchor constraintEqualToConstant:116]
        ]];
    }
    self.header = header;
    [header configureForIndex:tab.selectedIndex];

    PAOrbitDock *dock = (PAOrbitDock *)[tab.view viewWithTag:PADockTag];
    if (![dock isKindOfClass:PAOrbitDock.class]) {
        dock = [[PAOrbitDock alloc] initWithFrame:CGRectZero];
        dock.tag = PADockTag;
        dock.manager = self;
        dock.translatesAutoresizingMaskIntoConstraints = NO;
        [tab.view addSubview:dock];
        [NSLayoutConstraint activateConstraints:@[
            [dock.leadingAnchor constraintEqualToAnchor:tab.view.leadingAnchor constant:22],
            [dock.trailingAnchor constraintEqualToAnchor:tab.view.trailingAnchor constant:-22],
            [dock.bottomAnchor constraintEqualToAnchor:tab.view.safeAreaLayoutGuide.bottomAnchor constant:-4],
            [dock.heightAnchor constraintEqualToConstant:58]
        ]];
    }
    self.dock = dock;
    [dock setSelectedIndex:tab.selectedIndex animated:NO];
    [dock refresh];

    [tab.view bringSubviewToFront:header];
    [tab.view bringSubviewToFront:dock];
    self.applying = NO;
}

- (void)updateForVisibleController:(UIViewController *)controller {
    if (!controller || !self.tabController) return;
    BOOL root = [self isRootVisibleController:controller];
    self.header.hidden = !root;
    self.dock.hidden = !root;
    self.tabController.additionalSafeAreaInsets = root ? UIEdgeInsetsMake(110, 0, 67, 0) : UIEdgeInsetsZero;

    UINavigationController *navigation = controller.navigationController;
    if (navigation) {
        [navigation setNavigationBarHidden:root animated:NO];
        if (!root) [self styleNavigationBar:navigation.navigationBar];
    }

    controller.overrideUserInterfaceStyle = UIUserInterfaceStyleDark;
    controller.view.backgroundColor = UIColor.clearColor;
    [self makeBackgroundsTransparent:controller.view depth:0];

    if (root && self.tabController.selectedIndex == 3) {
        [self installCustomKeypadInController:controller];
    } else {
        [self restoreKeypadIfNeeded];
    }

    [self.tabController.view bringSubviewToFront:self.header];
    [self.tabController.view bringSubviewToFront:self.dock];
}

- (void)styleNavigationBar:(UINavigationBar *)bar {
    UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
    [appearance configureWithTransparentBackground];
    appearance.backgroundColor = UIColor.clearColor;
    appearance.shadowColor = UIColor.clearColor;
    appearance.titleTextAttributes = @{NSForegroundColorAttributeName: UIColor.whiteColor,
                                       NSFontAttributeName: [UIFont systemFontOfSize:18 weight:UIFontWeightSemibold]};
    bar.standardAppearance = appearance;
    bar.scrollEdgeAppearance = appearance;
    bar.compactAppearance = appearance;
    bar.tintColor = PAAccent();
}

- (void)makeBackgroundsTransparent:(UIView *)view depth:(NSInteger)depth {
    if (!view || depth > 10) return;
    if ([view isKindOfClass:UITableView.class]) {
        UITableView *table = (UITableView *)view;
        table.backgroundColor = UIColor.clearColor;
        table.separatorStyle = UITableViewCellSeparatorStyleNone;
        table.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    } else if ([view isKindOfClass:UICollectionView.class]) {
        view.backgroundColor = UIColor.clearColor;
    } else if ([view isKindOfClass:UISearchBar.class]) {
        UISearchBar *search = (UISearchBar *)view;
        search.searchBarStyle = UISearchBarStyleMinimal;
        search.tintColor = PAAccent();
        search.searchTextField.backgroundColor = [UIColor colorWithWhite:1 alpha:0.085];
        search.searchTextField.textColor = UIColor.whiteColor;
        search.searchTextField.layer.cornerRadius = 16;
        search.searchTextField.layer.cornerCurve = kCACornerCurveContinuous;
    } else if ([view isKindOfClass:UISegmentedControl.class] && self.tabController.selectedIndex == 1) {
        view.hidden = YES;
    } else if (![view isKindOfClass:UILabel.class] && ![view isKindOfClass:UIButton.class]) {
        NSString *name = NSStringFromClass(view.class);
        if (![name hasPrefix:@"PA"] && ![name containsString:@"Remote"] && ![name containsString:@"AV"]) {
            if (view.backgroundColor && CGColorGetAlpha(view.backgroundColor.CGColor) > 0.6) view.backgroundColor = UIColor.clearColor;
        }
    }
    for (UIView *subview in view.subviews) [self makeBackgroundsTransparent:subview depth:depth + 1];
}

- (void)tableViewDidLayout:(UITableView *)tableView {
    if (!PABool(@"enabled", YES) || !self.tabController || self.tabController.selectedIndex == 3) return;
    UIViewController *visible = [self visibleControllerFrom:self.tabController];
    if (!visible || ![tableView isDescendantOfView:visible.view]) return;
    tableView.backgroundColor = UIColor.clearColor;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    for (UITableViewCell *cell in tableView.visibleCells) [self styleCell:cell];
}

- (void)styleCell:(UITableViewCell *)cell {
    UIView *card = [cell viewWithTag:PACardTag];
    if (!card) {
        card = [[UIView alloc] initWithFrame:CGRectZero];
        card.tag = PACardTag;
        card.userInteractionEnabled = NO;
        card.layer.cornerCurve = kCACornerCurveContinuous;
        card.layer.borderWidth = 0.55;
        [cell insertSubview:card atIndex:0];
    }
    CGFloat height = CGRectGetHeight(cell.bounds);
    CGFloat vertical = height < 52 ? 2 : 4;
    card.frame = CGRectInset(cell.bounds, 12, vertical);
    card.layer.cornerRadius = height < 52 ? 13 : 19;
    card.backgroundColor = [UIColor colorWithWhite:1 alpha:height < 52 ? 0.035 : 0.065];
    card.layer.borderColor = [UIColor colorWithWhite:1 alpha:0.11].CGColor;
    cell.backgroundColor = UIColor.clearColor;
    cell.contentView.backgroundColor = UIColor.clearColor;
    cell.tintColor = PAAccent();
    cell.selectedBackgroundView = nil;
}

- (void)installCustomKeypadInController:(UIViewController *)controller {
    UIView *existing = [controller.view viewWithTag:PAKeypadTag];
    if ([existing isKindOfClass:PACustomKeypadView.class]) {
        for (UIView *subview in controller.view.subviews) {
            if (subview.tag != PAKeypadTag) subview.hidden = YES;
        }
        self.keypadController = controller;
        existing.hidden = NO;
        return;
    }
    for (UIView *subview in controller.view.subviews) {
        if (subview.tag != PAKeypadTag) subview.hidden = YES;
    }
    PACustomKeypadView *keypad = [[PACustomKeypadView alloc] initWithFrame:controller.view.bounds];
    keypad.tag = PAKeypadTag;
    [controller.view addSubview:keypad];
    self.keypadController = controller;
}

- (void)restoreKeypadIfNeeded {
    if (!self.keypadController) return;
    for (UIView *subview in self.keypadController.view.subviews) {
        if (subview.tag != PAKeypadTag) subview.hidden = NO;
    }
    UIView *keypad = [self.keypadController.view viewWithTag:PAKeypadTag];
    keypad.hidden = YES;
}

- (void)headerSearchPressed {
    UIViewController *visible = [self visibleControllerFrom:self.tabController];
    UISearchBar *search = (UISearchBar *)[self firstViewOfClass:UISearchBar.class inView:visible.view];
    if (search) {
        [search.searchTextField becomeFirstResponder];
        PAHaptic(UIImpactFeedbackStyleLight);
    }
}

- (void)headerAddPressed {
    UIViewController *visible = [self visibleControllerFrom:self.tabController];
    UIButton *candidate = [self addButtonInView:visible.view];
    if (candidate) {
        [candidate sendActionsForControlEvents:UIControlEventTouchUpInside];
        PAHaptic(UIImpactFeedbackStyleMedium);
        return;
    }
    UIBarButtonItem *item = visible.navigationItem.rightBarButtonItem;
    if (item.target && item.action) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        [item.target performSelector:item.action withObject:item];
#pragma clang diagnostic pop
    }
}

- (void)showAllRecents { [self setRecentsSegment:0]; }
- (void)showMissedRecents { [self setRecentsSegment:1]; }

- (void)setRecentsSegment:(NSInteger)index {
    UISegmentedControl *segment = (UISegmentedControl *)[self firstViewOfClass:UISegmentedControl.class inView:self.tabController.view];
    if (segment && segment.numberOfSegments >= 2) {
        segment.selectedSegmentIndex = index;
        [segment sendActionsForControlEvents:UIControlEventValueChanged];
        PAHaptic(UIImpactFeedbackStyleLight);
    }
}

- (void)presentSettings {
    UIViewController *presenter = [self visibleControllerFrom:self.tabController];
    if (!presenter) return;
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"PhoneAura"
                                                                   message:@"Choose an atmosphere. Changes apply instantly."
                                                            preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray *names = @[@"Ocean", @"Aurora", @"Emerald", @"Sunset"];
    for (NSInteger index = 0; index < names.count; index++) {
        [sheet addAction:[UIAlertAction actionWithTitle:names[index] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            PAWrite(@"accentStyle", @(index));
            [self reloadPreferences];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"Cancel" style:UIAlertActionStyleCancel handler:nil]];
    if (sheet.popoverPresentationController) {
        sheet.popoverPresentationController.sourceView = self.header.settingsButton;
        sheet.popoverPresentationController.sourceRect = self.header.settingsButton.bounds;
    }
    [presenter presentViewController:sheet animated:YES completion:nil];
}

- (UIView *)firstViewOfClass:(Class)klass inView:(UIView *)view {
    if ([view isKindOfClass:klass] && view.tag < 915000) return view;
    for (UIView *subview in view.subviews) {
        UIView *found = [self firstViewOfClass:klass inView:subview];
        if (found) return found;
    }
    return nil;
}

- (UIButton *)addButtonInView:(UIView *)view {
    if ([view isKindOfClass:UIButton.class]) {
        UIButton *button = (UIButton *)view;
        NSString *text = [button titleForState:UIControlStateNormal] ?: button.accessibilityLabel ?: @"";
        if ([text isEqualToString:@"+"] || [text localizedCaseInsensitiveContainsString:@"add"]) return button;
    }
    for (UIView *subview in view.subviews) {
        UIButton *found = [self addButtonInView:subview];
        if (found) return found;
    }
    return nil;
}

- (BOOL)isRootVisibleController:(UIViewController *)controller {
    UINavigationController *navigation = controller.navigationController;
    if (!navigation) return YES;
    return navigation.viewControllers.firstObject == controller;
}

- (UITabBarController *)tabControllerForController:(UIViewController *)controller {
    UIViewController *cursor = controller;
    while (cursor) {
        if ([cursor isKindOfClass:UITabBarController.class]) return (UITabBarController *)cursor;
        cursor = cursor.parentViewController;
    }
    return controller.tabBarController;
}

- (UITabBarController *)locateTabController {
    UIWindow *window = nil;
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
            if (!candidate.hidden && candidate.windowLevel == UIWindowLevelNormal) { window = candidate; break; }
        }
        if (window) break;
    }
    return [self findTabControllerIn:window.rootViewController];
}

- (UITabBarController *)findTabControllerIn:(UIViewController *)controller {
    if (!controller) return nil;
    if ([controller isKindOfClass:UITabBarController.class]) return (UITabBarController *)controller;
    for (UIViewController *child in controller.childViewControllers) {
        UITabBarController *found = [self findTabControllerIn:child];
        if (found) return found;
    }
    return [self findTabControllerIn:controller.presentedViewController];
}

- (UIViewController *)visibleControllerFrom:(UIViewController *)controller {
    if (!controller) return nil;
    if (controller.presentedViewController) return [self visibleControllerFrom:controller.presentedViewController];
    if ([controller isKindOfClass:UINavigationController.class]) return [self visibleControllerFrom:((UINavigationController *)controller).visibleViewController];
    if ([controller isKindOfClass:UITabBarController.class]) return [self visibleControllerFrom:((UITabBarController *)controller).selectedViewController];
    return controller;
}
@end
